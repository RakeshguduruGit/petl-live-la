"use client"

import handler from "../api/la/end"

export default function SyntheticV0PageForDeployment() {
  return <handler />
}